<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="col-12 data_web">
		<div class="row">
			<div class="col-12">
				<h2>Ketik Catatanmu</h2>
				<form>
					<input type="text" name="post" id="postingan" placeholder="Ketikkan sesuatu...">
					<input type="submit" name="kirim" id="kirim" value="Kirim"><br>
					<div class="attachment">
						<i class="fa fa-file fa-2x" style="color: gray"></i>
						<i class="fa fa-link fa-2x" style="color: gray"></i>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>