<?php

	include "koneksi.php";
	$id = $_GET["id"];
	$sql = "select * from tbuser where id=".$id;
	$query = mysqli_query($con,$sql);
	$re = mysqli_fetch_array($query);
	$username = $re["name"];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="col-12 data_web">
		<div class="row">
			<div class="col-12">
				<h2>Ketikkan pesanmu</h2>
				<form>
					<input type="text" name="pengirim" id="pengirim" placeholder="Nama penerima">
					<input type="submit" name="kirim" id="kirim" value="Kirim"><br><br>
					<textarea name="pesan" id="pesan" placeholder="Ketikkan sesuatu"></textarea><br>
					<div class="attachment">
						<i class="fa fa-file fa-2x" style="color: gray"></i>
						<i class="fa fa-link fa-2x" style="color: gray"></i>
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php

		$sql4 = ("select * from tbinbox where to_id=".$id);
		$query4 = mysqli_query($con,$sql4);
		$num4 = mysqli_num_rows($query4);
		$re4 = mysqli_fetch_array($query4);

		for($i=0;$i<$num4;$i++){
			$id_pesan = $re4["id_message"];
			$sql5 = ("select id_user from tb_message where id=".$id_pesan);
			$query5 = mysqli_query($con,$sql5);
			$re5 = mysqli_fetch_array($query5);
			$id_pengirim = $re5["id_user"];
			$sql6 = ("select name from tbuser where id=".$id_pengirim);
			$query6 = mysqli_query($con,$sql6);
			$re6 = mysqli_fetch_array($query6);
			$nama_pengirim = $re6["name"];

			$sql7 = ("select * from tb_message where id_user=".$id_pengirim);
			$query7 = mysqli_query($con,$sql7);
			$re7 = mysqli_fetch_array($query7);
			$isi_pesan = $re7["message"];
			$tanggal = $re7["time_sent"];
			?>	

				<div class="col-12 data_web">
					<div class="row">
						<div class="col-12">
							<h2>Pesan dari <?php echo $nama_pengirim ?></h2>
							<p>Tanggal <?php echo $tanggal ?></p>
							<p class="isi"><?php echo $isi_pesan ?></p>
						</div>
					</div>		
				</div>

			<?php 
		}

	?>
</body>
</html>