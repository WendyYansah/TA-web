<?php

	include "koneksi.php";
	session_start();

	$s = $_GET["s"];

	if($s == "login"){

		$user = $_POST["nama"];
		$pass = substr(md5($_POST["pass"]),0,16);

		$sql = ("select * from tbuser where name='".$user."' AND password='".$pass."';");
		$query = mysqli_query($con,$sql);
		$num = mysqli_num_rows($query);
		$re = mysqli_fetch_array($query);

		$id_db = $re["image_id_key"];
		$user_db = $re["name"];
		$pass_db = $re["password"];

		if($user == $user_db && $pass == $pass_db){
			$status = $re["id_user_type"];
			$id_db = $re["image_id_key"];
			$_SESSION["image_id"] = $id_db;
			$_SESSION["user"] = $user;
			$_SESSION["pass"] = $pass;
			$_SESSION["status"] = $status;
			header("location: menu.php");
		}
		else{
			?>
				<script type="text/javascript">
					alert("Maaf, Username atau Password tidak ditemukan. Silahkan coba lagi.");
					location.href = "index.php";
				</script>
			<?php
		}
	}
	elseif($s == "daftar"){
		$user_isi = $_POST["nama_reg"];
		$email_isi = $_POST["email_reg"];
		$pass_isi = md5($_POST["pass_reg"]);
		$nis_isi = $_POST["nis_reg"];
		$status_isi = $_POST["status"];
		$id_db = "1";

		if($status_isi=="murid"){
			$status_isi = "1";
		}
		elseif($status_isi=="guru"){
			$status_isi = "2";
		}
		elseif($status_isi=="ortu"){
			$status_isi = "3";
		}

		$sql = ("insert into tbuser(name,password,email,nis,id_user_type,image_id_key) values('$user_isi','$pass_isi','$email_isi','$nis_isi','$status_isi','$id_db');");
		$query = mysqli_query($con, $sql)or die($sql);


		$_SESSION["image_id"] = $id_db;
		$_SESSION["user"] = $user_isi;
		$_SESSION["pass"] = $pass_isi;
		$_SESSION["status"] = $status_isi;
		header("location: menu.php");
	}


?>