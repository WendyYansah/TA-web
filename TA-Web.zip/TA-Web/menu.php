<?php

	include "koneksi.php";
	session_start();

	$user = $_SESSION["user"];
	$pass = $_SESSION["pass"];
	$status = $_SESSION["status"];
	$id = $_SESSION["image_id"];

	if($status=="1"){
		$status = "Siswa";
	}
	elseif($status=="2"){
		$status = "Guru";
	}
	elseif($status=="3"){
		$status = "Orang tua";
	}

	$sql = ("select image from profile_img where image_id=".$id.";");
	$query = mysqli_query($con,$sql);
	$re = mysqli_fetch_array($query);
	$img = $re["image"];

	$sql2 = ("select * from tbuser where name='".$user."' AND password='".$pass."';");
	$query2 = mysqli_query($con,$sql2);
	$num2 = mysqli_num_rows($query2);
	$re2 = mysqli_fetch_array($query2);
	$id_user = $re2["id"];

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/grid.css">
	<link rel="stylesheet" type="text/css" href="css/style10.css">
	<link rel="stylesheet" type="text/css" href="Icons/font-awesome.css">
	<script src="js/jquery-3.3.1.js"></script>
	<script>
		
	</script>
	<script src="js/ajax_play.js"></script>
</head>
<body class="index" onload="home()">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="row ">
					<div class="col-12 header">
						<div class="row">
							<div class="col-2 logo title_part">
								logo disini
							</div>
							<div class="col-7 title_part">
								Title disini
							</div>
							<div class="col-3">
								<div class="row">
									<div class="col-8 user_name" align="right">
										<h3 style="margin: 0;"><?php echo $user ?></h3>
										<p style="margin: 0; font-size: 14px;"><?php echo $status ?></p>
									</div>
									<div class="col-4" align="center">
										<img src="data:image/jpeg; base64, <?php echo base64_encode($img); ?>" width=50 height=50 class="data_img" id="imgdata">
									</div>	
								</div>
							</div>
						</div>
					</div>
					<div class="col-12 navbar">
						<div class="row">
							<div class="items_list">
								<ul>
									<li onclick="home()"><i class="fa fa-home fa-2x"></i><br>Beranda</li>
									<li onclick="pesan(<?php echo "'$id_user','$user'"; ?>)"><i class="fa fa-inbox fa-2x"></i><br>Pesan</li>
									<li onclick=""><i class="fa fa-sticky-note fa-2x"></i><br>Catatan</li>
									<li onclick=""><i class="fa fa-book fa-2x"></i><br>Tugas</li>
									<li onclick=""><i class="fa fa-bar-chart fa-2x"></i><br>Kemajuan</li>
									<li onclick=""><i class="fa fa-calendar fa-2x"></i><br>Kalender</li>
									<li onclick=""><i class="fa fa-comments fa-2x"></i><br>Diskusi</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-12" id="result"></div>
			</div>
		</div>
	</div>
</body>
</html>