<!DOCTYPE html>
<html>
<head>
	<title>TA</title>
	<!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> -->
	<!-- <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"> -->
	<link rel="stylesheet" type="text/css" href="css/grid.css">
	<link rel="stylesheet" type="text/css" href="css/style10.css">
	<script src="js/jquery-3.3.1.js"></script>
	<script>
		$(document).ready(function(){
			var div = $("#layer1");
			div.animate({bottom: "15px", opacity: "1"}, "slow");
			$("#layer1").fadeTo("slow",1);
			$("#daftar").click(function(){
				$("#trig_reg").show();
				$("#trig_log").hide();
			});
			$("#login").click(function(){
				$("#trig_log").show();
				$("#trig_reg").hide();
			});
		});
	</script>
	<script type="text/javascript">
	</script>
</head>
<body class="login" id="layer1">
	<div class="container">
		<div class="row">
			<div class="data" id="trig_log">
				<div class="col-12">
					<div class="row">
						<div class="col-4"></div>
						<div class="col-4 box_wrap" align="center">
							<div class="row">
								<div class="col-12 isi_form">
									<h1>Connect Closer, Become Smarter</h1>
									<p>S.E.T menghubungkan siswa, guru, dan orang tua dalam instansi sekolah anda dan membantu anda dalam dunia edukasi di sekolah sehari-hari.</p>
									<form action="login.php?s=login" method="POST" class="login_data">
										<input type="text" name="nama" id="nama_user" placeholder="Username" required><br>
										<input type="password" name="pass" id="pass_user" placeholder="Password" required><br>
										<input type="submit" value="Masuk" name="submit">
									</form>
									<button onclick="forgot()" class="forgot">Lupa Password?</button>
								</div>
								<div class="col-12 isi_form2">
									<h3>Tidak punya akun?</h2>
									<button onclick="register()" id="daftar" class="daftar">
										Buat Akun
									</button>
								</div>
							</div>
						</div>
						<div class="col-4"></div>
					</div>
				</div>
			</div>
			<div class="register" style="display: none;" id="trig_reg">
				<div class="col-12">
					<div class="row">
						<div class="col-4"></div>
						<div class="col-4 box_wrap" align="center">
							<div class="row">
								<div class="col-12 isi_form">
									<h1>Connect Closer, Become Smarter</h1>
									<p>Belum punya akun? Ayo bergabung bersama kami!</p>
									<form action="login.php?s=daftar" method="POST" class="login_data">
										<input type="text" name="nama_reg" id="nama_reg" placeholder="Nama Anda" required><br>
										<input type="email" name="email_reg" id="email_reg" placeholder="Email Anda" required><br>
										<input type="password" name="pass_reg" id="pass_reg" placeholder="Password" required><br>
										<input type="text" name="nis_reg" id="nis_reg" placeholder="NIS anda (Nb: Hanya untuk murid)"><br>
										Anda adalah : <br>
										<input type="radio" name="status" value="murid">Murid
										<input type="radio" name="status" value="guru">Guru
										<input type="radio" name="status" value="ortu">Orang Tua
										<input type="submit" name="kirim_data" value="Buat Akun">
									</form>
									<button onclick="forgot()" class="forgot">Lupa Password?</button>
								</div>
								<div class="col-12 isi_form2">
									<h3>Sudah punya akun?</h2>
									<button id="login" class="daftar">
										Login
									</button>
								</div>
							</div>
						</div>
						<div class="col-4"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>	