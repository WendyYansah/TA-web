<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/grid.css">
	<link rel="stylesheet" type="text/css" href="css/style10.css">
	<script src="js/jquery-3.3.1.js"></script>
</head>
<body class="login">
	<div class="container">
		<div class="row">
			<div class="col-12" style="background-color: white"></div>
		</div>
	</div>
</body>
</html>