function buat_ajax(){
	if(window.XMLHttpRequest){
		return new XMLHttpRequest();
	}
	if(window.ActiveXObject){
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
	return null;
}

function home(){
	url = "part/halaman_home.php";
	url = url+"?ssid="+Math.random();
	ajaxku = buat_ajax();
	ajaxku.onreadystatechange = result;
	ajaxku.open("GET",url,true);
	ajaxku.send(null);
}

function pesan(id, user){
	url = "part/halaman_inbox.php?id="+id+"&user="+user;
	url = url+"?ssid="+Math.random();
	ajaxku = buat_ajax();
	ajaxku.onreadystatechange = result;
	ajaxku.open("GET",url,true);
	ajaxku.send(null);
}

function result(){
	if(ajaxku.readyState==4){
		data = ajaxku.responseText;
		document.getElementById("result").innerHTML = data;
	}
}