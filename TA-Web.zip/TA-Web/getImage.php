<?php
	
	include "koneksi.php";
	$id = $_GET["id"];

	$sql = ();
	$query = mysqli_query($con, $sql);
	$re = mysqli_fetch_array($query);
	header("Content-type: image/png");
	echo $re["image"];

?>